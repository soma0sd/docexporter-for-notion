(function() {
  "use strict";
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "DOWNLOAD_FILE") {
      chrome.downloads.download(
        { url: msg.dataUrl, filename: msg.filename, saveAs: false },
        (downloadId) => {
          sendResponse({ ok: true, downloadId });
        }
      );
      return true;
    }
    if (msg.type === "FETCH_IMAGE") {
      fetch(msg.url).then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.arrayBuffer();
      }).then((buffer) => {
        const bytes = new Uint8Array(buffer);
        const chunks = [];
        const CHUNK = 32768;
        for (let i = 0; i < bytes.length; i += CHUNK) {
          chunks.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK)));
        }
        const base64 = btoa(chunks.join(""));
        let mime = "image/png";
        if (bytes[0] === 255 && bytes[1] === 216) mime = "image/jpeg";
        else if (bytes[0] === 71 && bytes[1] === 73) mime = "image/gif";
        else if (bytes[0] === 82 && bytes[1] === 73) mime = "image/webp";
        sendResponse({ ok: true, dataUrl: `data:${mime};base64,${base64}` });
      }).catch((err) => {
        console.warn("[NotionExport] FETCH_IMAGE failed:", msg.url, err);
        sendResponse({ ok: false });
      });
      return true;
    }
    return false;
  });
})();
