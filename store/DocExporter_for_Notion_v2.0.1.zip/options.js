(function() {
  "use strict";
  const DEFAULT_SETTINGS = {
    fonts: {
      global: "",
      h1: "",
      h2: "",
      h3: "",
      body: "",
      quote: "",
      code: "Courier New",
      caption: ""
    },
    colors: {
      global: "",
      h1: "",
      h2: "",
      h3: "",
      body: "",
      quote: "",
      code: "",
      caption: ""
    },
    cover: {
      image: null,
      textElements: [],
      titleSlot: { enabled: true, x: 10, y: 35, width: 80, style: "title" },
      authorSlot: { enabled: true, x: 10, y: 45, width: 80, style: "subtitle" }
    }
  };
  const STORAGE_KEY = "exportSettings";
  function deepMerge(target, src) {
    const out = { ...target };
    for (const key of Object.keys(target)) {
      const sv = src[key];
      if (sv === void 0) continue;
      const tv = target[key];
      if (tv && typeof tv === "object" && !Array.isArray(tv) && sv && typeof sv === "object" && !Array.isArray(sv)) {
        out[key] = deepMerge(tv, sv);
      } else {
        out[key] = sv;
      }
    }
    return out;
  }
  async function loadSettings() {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    const stored = result[STORAGE_KEY];
    if (!stored) return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
    return deepMerge(
      DEFAULT_SETTINGS,
      stored
    );
  }
  async function saveSettings(settings2) {
    await chrome.storage.local.set({ [STORAGE_KEY]: settings2 });
  }
  function resizeImageFile(file, maxWidth = 1200) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error("Failed to load image"));
        img.onload = () => {
          let w = img.naturalWidth;
          let h = img.naturalHeight;
          if (w > maxWidth) {
            h = Math.round(h * (maxWidth / w));
            w = maxWidth;
          }
          const canvas = document.createElement("canvas");
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext("2d");
          ctx.fillStyle = "white";
          ctx.fillRect(0, 0, w, h);
          ctx.drawImage(img, 0, 0, w, h);
          resolve(canvas.toDataURL("image/jpeg", 0.85));
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }
  const messages = {
    en: {
      btnLabel: "Export",
      menuDocx: "Download as DOCX",
      menuHwpx: "Download as HWPX",
      toastLoading: "Reading page…",
      toastConverting: "Converting to $1…",
      toastDone: "Download started",
      toastError: "Error: $1",
      tocTitle: "Table of Contents",
      optionsTitle: "Settings",
      optionsFontSection: "Font Settings",
      optionsFontGlobal: "Global font",
      optionsFontH1: "Heading 1 font",
      optionsFontH2: "Heading 2 font",
      optionsFontH3: "Heading 3 font",
      optionsFontBody: "Body font",
      optionsFontQuote: "Quote font",
      optionsFontCode: "Code font",
      optionsFontCaption: "Caption font",
      optionsFontPlaceholder: "System default",
      optionsFontPermission: "Click to load system fonts",
      optionsCoverSection: "Cover Page",
      optionsCoverUpload: "Upload image",
      optionsCoverRemove: "Remove",
      optionsCoverAddText: "Add text",
      optionsCoverPageTitle: "Page title",
      optionsCoverPageAuthor: "Author",
      optionsCoverPageTitlePlaceholder: "[Page title]",
      optionsCoverPageAuthorPlaceholder: "[Author]",
      optionsCoverElementEnabled: "Show",
      optionsCoverStyleLabel: "Style",
      optionsSave: "Save",
      optionsReset: "Reset to defaults",
      optionsSaved: "Settings saved",
      optionsSettingsLink: "Settings",
      optionsCoverStyleTitle: "Title",
      optionsCoverStyleSubtitle: "Subtitle",
      optionsCoverStyleH1: "Heading 1",
      optionsCoverStyleH2: "Heading 2",
      optionsCoverStyleH3: "Heading 3",
      optionsCoverStyleBody: "Body",
      optionsCoverStyleCaption: "Caption",
      optionsFontColor: "Text color",
      optionsFontColorReset: "Reset to default color"
    },
    ko: {
      btnLabel: "내보내기",
      menuDocx: "DOCX로 다운로드",
      menuHwpx: "HWPX로 다운로드",
      toastLoading: "페이지 읽는 중…",
      toastConverting: "$1(으)로 변환 중…",
      toastDone: "다운로드가 시작되었습니다",
      toastError: "오류: $1",
      tocTitle: "목차",
      optionsTitle: "설정",
      optionsFontSection: "글꼴 설정",
      optionsFontGlobal: "전체 글꼴",
      optionsFontH1: "제목 1 글꼴",
      optionsFontH2: "제목 2 글꼴",
      optionsFontH3: "제목 3 글꼴",
      optionsFontBody: "본문 글꼴",
      optionsFontQuote: "인용문 글꼴",
      optionsFontCode: "코드 글꼴",
      optionsFontCaption: "캡션 글꼴",
      optionsFontPlaceholder: "시스템 기본값",
      optionsFontPermission: "클릭하여 시스템 글꼴 불러오기",
      optionsCoverSection: "표지",
      optionsCoverUpload: "이미지 업로드",
      optionsCoverRemove: "제거",
      optionsCoverAddText: "텍스트 추가",
      optionsCoverPageTitle: "페이지 제목",
      optionsCoverPageAuthor: "작성자",
      optionsCoverPageTitlePlaceholder: "[페이지 제목]",
      optionsCoverPageAuthorPlaceholder: "[작성자]",
      optionsCoverElementEnabled: "표시",
      optionsCoverStyleLabel: "스타일",
      optionsSave: "저장",
      optionsReset: "기본값으로 초기화",
      optionsSaved: "설정이 저장되었습니다",
      optionsSettingsLink: "설정",
      optionsCoverStyleTitle: "제목",
      optionsCoverStyleSubtitle: "부제목",
      optionsCoverStyleH1: "제목 1",
      optionsCoverStyleH2: "제목 2",
      optionsCoverStyleH3: "제목 3",
      optionsCoverStyleBody: "본문",
      optionsCoverStyleCaption: "캡션",
      optionsFontColor: "글자 색상",
      optionsFontColorReset: "기본 색상으로 초기화"
    }
  };
  function detectLang() {
    const lang2 = (navigator.language ?? "en").toLowerCase();
    if (lang2.startsWith("ko")) return "ko";
    return "en";
  }
  const lang = detectLang();
  const dict = messages[lang] ?? messages["en"];
  function t(key, ...args) {
    let msg = dict[key] ?? key;
    args.forEach((a, i) => {
      msg = msg.replace(`$${i + 1}`, a);
    });
    return msg;
  }
  let settings;
  let systemFonts = [];
  let fontsLoaded = false;
  function localize() {
    setText("options-title", t("optionsTitle"));
    setText("font-section-title", t("optionsFontSection"));
    setText("cover-section-title", t("optionsCoverSection"));
    setText("btn-cover-upload", t("optionsCoverUpload"));
    setText("btn-cover-remove", t("optionsCoverRemove"));
    setText("btn-add-text", `+ ${t("optionsCoverAddText")}`);
    setText("btn-save", t("optionsSave"));
    setText("save-status", t("optionsSaved"));
    setText("btn-reset", t("optionsReset"));
  }
  function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  }
  const FONT_SLOTS = [
    { key: "global", labelKey: "optionsFontGlobal" },
    { key: "h1", labelKey: "optionsFontH1" },
    { key: "h2", labelKey: "optionsFontH2" },
    { key: "h3", labelKey: "optionsFontH3" },
    { key: "body", labelKey: "optionsFontBody" },
    { key: "quote", labelKey: "optionsFontQuote" },
    { key: "code", labelKey: "optionsFontCode" },
    { key: "caption", labelKey: "optionsFontCaption" }
  ];
  async function loadSystemFonts() {
    if (fontsLoaded) return;
    if (!window.queryLocalFonts) return;
    try {
      const fonts = await window.queryLocalFonts();
      const families = /* @__PURE__ */ new Set();
      for (const f of fonts) families.add(f.family);
      systemFonts = Array.from(families).sort((a, b) => a.localeCompare(b));
      fontsLoaded = true;
    } catch {
    }
  }
  function buildFontGrid() {
    const grid = document.getElementById("font-grid");
    grid.innerHTML = "";
    for (const slot of FONT_SLOTS) {
      const label = document.createElement("label");
      label.textContent = t(slot.labelKey);
      grid.appendChild(label);
      const row = document.createElement("div");
      row.className = "font-row";
      const picker = document.createElement("div");
      picker.className = "font-picker";
      const input = document.createElement("input");
      input.type = "text";
      input.placeholder = t("optionsFontPlaceholder");
      input.value = settings.fonts[slot.key];
      input.dataset.slot = slot.key;
      const dropdown = document.createElement("div");
      dropdown.className = "font-dropdown";
      picker.appendChild(input);
      picker.appendChild(dropdown);
      row.appendChild(picker);
      const colorWrap = document.createElement("div");
      colorWrap.className = "color-picker-wrap";
      const colorInput = document.createElement("input");
      colorInput.type = "color";
      colorInput.className = "color-input";
      colorInput.value = settings.colors[slot.key] || "#000000";
      colorInput.title = t("optionsFontColor");
      const colorClear = document.createElement("button");
      colorClear.className = "color-clear";
      colorClear.textContent = "×";
      colorClear.title = t("optionsFontColorReset");
      colorClear.style.display = settings.colors[slot.key] ? "" : "none";
      if (settings.colors[slot.key]) {
        colorWrap.classList.add("active");
      }
      colorInput.addEventListener("input", () => {
        settings.colors[slot.key] = colorInput.value;
        colorClear.style.display = "";
        colorWrap.classList.add("active");
      });
      colorClear.addEventListener("click", () => {
        settings.colors[slot.key] = "";
        colorInput.value = "#000000";
        colorClear.style.display = "none";
        colorWrap.classList.remove("active");
      });
      colorWrap.appendChild(colorInput);
      colorWrap.appendChild(colorClear);
      row.appendChild(colorWrap);
      grid.appendChild(row);
      input.addEventListener("focus", async () => {
        await loadSystemFonts();
        renderFontDropdown(dropdown, input, slot.key);
        dropdown.classList.add("open");
      });
      input.addEventListener("input", () => {
        renderFontDropdown(dropdown, input, slot.key);
      });
      input.addEventListener("blur", () => {
        setTimeout(() => {
          dropdown.classList.remove("open");
          settings.fonts[slot.key] = input.value;
        }, 200);
      });
      input.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          dropdown.classList.remove("open");
          input.blur();
        }
      });
    }
  }
  function renderFontDropdown(dropdown, input, slot) {
    dropdown.innerHTML = "";
    const query = input.value.toLowerCase();
    if (!fontsLoaded) {
      const empty = document.createElement("div");
      empty.className = "font-dropdown-empty";
      empty.textContent = t("optionsFontPermission");
      empty.addEventListener("mousedown", async (e) => {
        e.preventDefault();
        await loadSystemFonts();
        renderFontDropdown(dropdown, input, slot);
      });
      dropdown.appendChild(empty);
      return;
    }
    const defaultItem = document.createElement("div");
    defaultItem.className = "font-dropdown-item";
    defaultItem.textContent = t("optionsFontPlaceholder");
    defaultItem.style.fontStyle = "italic";
    defaultItem.addEventListener("mousedown", (e) => {
      e.preventDefault();
      input.value = "";
      settings.fonts[slot] = "";
      dropdown.classList.remove("open");
    });
    dropdown.appendChild(defaultItem);
    const filtered = query ? systemFonts.filter((f) => f.toLowerCase().includes(query)) : systemFonts;
    for (const family of filtered) {
      const item = document.createElement("div");
      item.className = "font-dropdown-item";
      const nameSpan = document.createElement("span");
      nameSpan.textContent = family;
      item.appendChild(nameSpan);
      const preview = document.createElement("span");
      preview.className = "preview";
      preview.textContent = "Aa";
      preview.style.fontFamily = `"${family}", sans-serif`;
      item.appendChild(preview);
      item.addEventListener("mousedown", (e) => {
        e.preventDefault();
        input.value = family;
        settings.fonts[slot] = family;
        dropdown.classList.remove("open");
      });
      dropdown.appendChild(item);
    }
    if (!filtered.length) {
      const empty = document.createElement("div");
      empty.className = "font-dropdown-empty";
      empty.textContent = "—";
      dropdown.appendChild(empty);
    }
  }
  function setupCoverImage() {
    const uploadBtn = document.getElementById("btn-cover-upload");
    const removeBtn = document.getElementById("btn-cover-remove");
    const fileInput = document.getElementById("cover-file-input");
    uploadBtn.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", async () => {
      const file = fileInput.files?.[0];
      if (!file) return;
      const dataUrl = await resizeImageFile(file);
      settings.cover.image = {
        dataUrl,
        x: 10,
        y: 10,
        width: 80,
        height: 40
      };
      fileInput.value = "";
      removeBtn.style.display = "";
      renderPreview();
    });
    removeBtn.addEventListener("click", () => {
      settings.cover.image = null;
      removeBtn.style.display = "none";
      renderPreview();
    });
  }
  const STYLE_OPTIONS = [
    { value: "title", labelKey: "optionsCoverStyleTitle" },
    { value: "subtitle", labelKey: "optionsCoverStyleSubtitle" },
    { value: "heading1", labelKey: "optionsCoverStyleH1" },
    { value: "heading2", labelKey: "optionsCoverStyleH2" },
    { value: "heading3", labelKey: "optionsCoverStyleH3" },
    { value: "body", labelKey: "optionsCoverStyleBody" },
    { value: "caption", labelKey: "optionsCoverStyleCaption" }
  ];
  function buildTextElements() {
    const container = document.getElementById("text-elements");
    container.innerHTML = "";
    for (const elem of settings.cover.textElements) {
      const row = document.createElement("div");
      row.className = "text-element";
      const textInput = document.createElement("input");
      textInput.type = "text";
      textInput.value = elem.text;
      textInput.addEventListener("input", () => {
        elem.text = textInput.value;
        renderPreview();
      });
      const styleSelect = document.createElement("select");
      for (const opt of STYLE_OPTIONS) {
        const option = document.createElement("option");
        option.value = opt.value;
        option.textContent = t(opt.labelKey);
        if (opt.value === elem.style) option.selected = true;
        styleSelect.appendChild(option);
      }
      styleSelect.addEventListener("change", () => {
        elem.style = styleSelect.value;
        renderPreview();
      });
      const deleteBtn = document.createElement("button");
      deleteBtn.className = "btn-delete";
      deleteBtn.textContent = "×";
      deleteBtn.addEventListener("click", () => {
        settings.cover.textElements = settings.cover.textElements.filter((e) => e.id !== elem.id);
        buildTextElements();
        renderPreview();
      });
      row.appendChild(textInput);
      row.appendChild(styleSelect);
      row.appendChild(deleteBtn);
      container.appendChild(row);
    }
  }
  function setupAddText() {
    document.getElementById("btn-add-text").addEventListener("click", () => {
      const elem = {
        id: crypto.randomUUID(),
        text: "",
        style: "body",
        x: 10,
        y: 50 + settings.cover.textElements.length * 8,
        width: 80
      };
      settings.cover.textElements.push(elem);
      buildTextElements();
      renderPreview();
    });
  }
  const AUTO_SLOTS = [
    { key: "titleSlot", labelKey: "optionsCoverPageTitle" },
    { key: "authorSlot", labelKey: "optionsCoverPageAuthor" }
  ];
  function buildAutoSlots() {
    const container = document.getElementById("auto-slots");
    container.innerHTML = "";
    for (const meta of AUTO_SLOTS) {
      const slot = settings.cover[meta.key];
      const row = document.createElement("div");
      row.className = "auto-slot";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = slot.enabled;
      cb.id = `auto-${meta.key}`;
      cb.addEventListener("change", () => {
        slot.enabled = cb.checked;
        renderPreview();
      });
      const label = document.createElement("label");
      label.htmlFor = cb.id;
      label.textContent = t(meta.labelKey);
      const select = document.createElement("select");
      for (const opt of STYLE_OPTIONS) {
        const o = document.createElement("option");
        o.value = opt.value;
        o.textContent = t(opt.labelKey);
        if (opt.value === slot.style) o.selected = true;
        select.appendChild(o);
      }
      select.addEventListener("change", () => {
        slot.style = select.value;
        renderPreview();
      });
      row.appendChild(cb);
      row.appendChild(label);
      row.appendChild(select);
      container.appendChild(row);
    }
  }
  const STYLE_RENDER = {
    title: { fontSize: 28, fontWeight: "bold", color: "#000000" },
    subtitle: { fontSize: 18, fontWeight: "normal", color: "#555555" },
    heading1: { fontSize: 22, fontWeight: "bold", color: "#1a1a1a" },
    heading2: { fontSize: 18, fontWeight: "bold", color: "#1a1a1a" },
    heading3: { fontSize: 15, fontWeight: "bold", color: "#1a1a1a" },
    body: { fontSize: 13, fontWeight: "normal", color: "#000000" },
    caption: { fontSize: 11, fontWeight: "normal", color: "#666666" }
  };
  function renderPreview() {
    const frame = document.getElementById("preview-frame");
    frame.innerHTML = "";
    const frameRect = frame.getBoundingClientRect();
    const scale = frameRect.width / 210;
    if (settings.cover.image) {
      const imgDiv = document.createElement("div");
      imgDiv.className = "preview-image";
      imgDiv.style.left = `${settings.cover.image.x}%`;
      imgDiv.style.top = `${settings.cover.image.y}%`;
      imgDiv.style.width = `${settings.cover.image.width}%`;
      imgDiv.style.height = `${settings.cover.image.height}%`;
      const img = document.createElement("img");
      img.src = settings.cover.image.dataUrl;
      imgDiv.appendChild(img);
      const handle = document.createElement("div");
      handle.className = "resize-handle";
      imgDiv.appendChild(handle);
      setupDrag(imgDiv, settings.cover.image, frame);
      setupResize(handle, imgDiv, settings.cover.image, frame);
      frame.appendChild(imgDiv);
    }
    const autoMeta = [
      { slot: settings.cover.titleSlot, placeholderKey: "optionsCoverPageTitlePlaceholder" },
      { slot: settings.cover.authorSlot, placeholderKey: "optionsCoverPageAuthorPlaceholder" }
    ];
    for (const { slot, placeholderKey } of autoMeta) {
      if (!slot.enabled) continue;
      const el = document.createElement("div");
      el.className = "preview-element";
      el.textContent = t(placeholderKey);
      const r = STYLE_RENDER[slot.style];
      Object.assign(el.style, {
        left: `${slot.x}%`,
        top: `${slot.y}%`,
        width: `${slot.width ?? 80}%`,
        fontSize: `${Math.max(8, r.fontSize * scale / 3)}px`,
        fontWeight: r.fontWeight,
        color: r.color,
        fontStyle: "italic",
        opacity: "0.85"
      });
      setupDrag(el, slot, frame);
      frame.appendChild(el);
    }
    for (const elem of settings.cover.textElements) {
      const el = document.createElement("div");
      el.className = "preview-element";
      el.textContent = elem.text || "(empty)";
      const r = STYLE_RENDER[elem.style];
      Object.assign(el.style, {
        left: `${elem.x}%`,
        top: `${elem.y}%`,
        width: `${elem.width ?? 80}%`,
        fontSize: `${Math.max(8, r.fontSize * scale / 3)}px`,
        fontWeight: r.fontWeight,
        color: r.color
      });
      setupDrag(el, elem, frame);
      frame.appendChild(el);
    }
  }
  function setupDrag(el, pos, container) {
    let startX = 0, startY = 0, startPosX = 0, startPosY = 0;
    const onMouseDown = (e) => {
      if (e.target.classList.contains("resize-handle")) return;
      e.preventDefault();
      el.classList.add("dragging");
      startX = e.clientX;
      startY = e.clientY;
      startPosX = pos.x;
      startPosY = pos.y;
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    };
    const onMouseMove = (e) => {
      const rect = container.getBoundingClientRect();
      const dx = (e.clientX - startX) / rect.width * 100;
      const dy = (e.clientY - startY) / rect.height * 100;
      pos.x = Math.max(0, Math.min(95, startPosX + dx));
      pos.y = Math.max(0, Math.min(95, startPosY + dy));
      el.style.left = `${pos.x}%`;
      el.style.top = `${pos.y}%`;
    };
    const onMouseUp = () => {
      el.classList.remove("dragging");
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };
    el.addEventListener("mousedown", onMouseDown);
  }
  function setupResize(handle, el, img, container) {
    let startX = 0, startY = 0, startW = 0, startH = 0;
    handle.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      startX = e.clientX;
      startY = e.clientY;
      startW = img.width;
      startH = img.height;
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    });
    const onMove = (e) => {
      const rect = container.getBoundingClientRect();
      const dw = (e.clientX - startX) / rect.width * 100;
      const dh = (e.clientY - startY) / rect.height * 100;
      img.width = Math.max(5, Math.min(100, startW + dw));
      img.height = Math.max(5, Math.min(100, startH + dh));
      el.style.width = `${img.width}%`;
      el.style.height = `${img.height}%`;
    };
    const onUp = () => {
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
    };
  }
  function setupActions() {
    document.getElementById("btn-save").addEventListener("click", async () => {
      await saveSettings(settings);
      const status = document.getElementById("save-status");
      status.classList.add("visible");
      setTimeout(() => status.classList.remove("visible"), 2e3);
    });
    document.getElementById("btn-reset").addEventListener("click", () => {
      settings = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
      buildFontGrid();
      buildAutoSlots();
      buildTextElements();
      document.getElementById("btn-cover-remove").style.display = "none";
      renderPreview();
    });
  }
  async function init() {
    settings = await loadSettings();
    localize();
    buildFontGrid();
    setupCoverImage();
    setupAddText();
    buildAutoSlots();
    buildTextElements();
    setupActions();
    if (settings.cover.image) {
      document.getElementById("btn-cover-remove").style.display = "";
    }
    renderPreview();
    window.addEventListener("resize", () => renderPreview());
  }
  init();
})();
