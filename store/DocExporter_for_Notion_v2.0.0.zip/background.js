(function() {
  "use strict";
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type !== "DOWNLOAD_FILE") return false;
    chrome.downloads.download(
      { url: msg.dataUrl, filename: msg.filename, saveAs: false },
      (downloadId) => {
        sendResponse({ ok: true, downloadId });
      }
    );
    return true;
  });
})();
